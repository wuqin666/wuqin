package com.app;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.app.utils.DruidUtil;
import org.junit.Test;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class TestDruid {
    @Test
    public  void  method1() throws Exception {
        Properties pro = new Properties();
        InputStream is = TestDruid.class.getClassLoader().getResourceAsStream("druid.properties");
        pro.load(is);
        DataSource ds = DruidDataSourceFactory.createDataSource(pro);
        Connection conn = ds.getConnection();
        DatabaseMetaData dmd = conn.getMetaData();
        String dbName = dmd.getDatabaseProductName();//数据库名
        String dbVersion = dmd.getDatabaseProductVersion();//数据库版本
        System.out.println(dbName+""+dbVersion);
    }

    @Test
    public  void method2() throws SQLException {
        Connection conn = DruidUtil.getInstance().getConnection();
        DatabaseMetaData dmd = conn.getMetaData();
        String dbName = dmd.getDatabaseProductName();//数据库名
        String dbVersion = dmd.getDatabaseProductVersion();//数据库版本
        System.out.println(dbName+""+dbVersion);
        DruidUtil.getInstance().closeConnection(conn);
    }

    // 返回数据库中的数据
    // 返回ResultSet的结果集
    @Test
    public  void  methods() throws SQLException {
        Connection conn = null; // 数据库连接
        PreparedStatement ps = null; //执行SQL语句接口
        ResultSet rs = null;// 查询返回结果
        String sql = null; //SQL语句 -select

        conn = DruidUtil.getInstance().getConnection();
        sql = "select * from t_user";
        ps = conn.prepareStatement(sql);
        rs = ps.executeQuery(); // 执行查询操作

        while(rs.next()){
            String id = rs.getString("id");
            String username = rs.getString("username");
            String password = rs.getString("password");
            System.out.println(id+" "+username+" "+password);

        }
        DruidUtil.getInstance().closeConnection(conn);
    }

    // 条件查询
    @Test
    public void  method4() throws SQLException {
        Connection conn = null; // 数据库连接
        PreparedStatement ps = null; //执行SQL语句接口
        ResultSet rs = null;// 查询返回结果
        String sql = null; //SQL语句 -select

        conn = DruidUtil.getInstance().getConnection();
        sql = "select * from  t_user where username = ? and password = ?";
        ps = conn.prepareStatement(sql);  // 把sql 语句放入到内存里面
        ps.setString(1,"wuqin");
        ps.setString(2,"123");

        rs = ps.executeQuery();
        while(rs.next()){
            String id = rs.getString("id");
            String username = rs.getString("username");
            String password = rs.getString("password");
            System.out.println(id+" "+username+" "+password);

        }
        DruidUtil.getInstance().closeConnection(conn);

    }
}
