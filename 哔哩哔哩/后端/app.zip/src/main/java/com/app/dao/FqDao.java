package com.app.dao;

import java.sql.SQLException;
import java.util.List;

public interface FqDao {

    public List getFqVideo(String fnum,String lnum) throws SQLException;
}
