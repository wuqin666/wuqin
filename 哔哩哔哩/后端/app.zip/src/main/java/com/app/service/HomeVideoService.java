package com.app.service;

import java.sql.SQLException;
import java.util.List;

public interface HomeVideoService {
    public List getHomeVideo() throws SQLException;
}
