package com.app.service;

import java.sql.SQLException;

public interface LoginService {
    public boolean loginUser(String username,String password) throws SQLException;
}
