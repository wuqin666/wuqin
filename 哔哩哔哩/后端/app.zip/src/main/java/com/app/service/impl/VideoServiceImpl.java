package com.app.service.impl;

import com.app.dao.VideoDao;
import com.app.dao.impl.VideoDaoImpl;
import com.app.service.VideoService;

import java.sql.SQLException;
import java.util.List;

public class VideoServiceImpl implements VideoService {

    // 依赖数据层接口 - VideoDao
    private VideoDao videoDao = new VideoDaoImpl();

    @Override
    public List getVideo() throws SQLException {
        return videoDao.getVideo();
    }

    @Override
    public List getVideoByTitle(String videoTitle) throws SQLException {
        return videoDao.getVideoByTitle(videoTitle);
    }
}
