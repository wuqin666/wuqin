package com.app.service;

import java.sql.SQLException;
import java.util.List;

public interface HelloService {

    public List getStudentByList() throws SQLException;

}
