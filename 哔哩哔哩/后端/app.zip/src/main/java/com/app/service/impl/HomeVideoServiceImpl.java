package com.app.service.impl;

import com.app.dao.HomeVideoDao;
import com.app.dao.impl.HomeVideoImpl;
import com.app.service.HomeVideoService;

import java.sql.SQLException;
import java.util.List;

public class HomeVideoServiceImpl implements HomeVideoService {
    private HomeVideoDao homeVideoDao = new HomeVideoImpl();
        @Override
        public List getHomeVideo() throws SQLException {
            return homeVideoDao.getHomeVideo();
        }
}
