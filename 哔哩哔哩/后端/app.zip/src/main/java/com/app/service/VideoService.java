package com.app.service;

import java.sql.SQLException;
import java.util.List;

/**
 * 业务逻辑 - 视频
 */
public interface VideoService {

    public List getVideo() throws SQLException;

    List getVideoByTitle(String videoTitle) throws SQLException;
}
