package com.app.controller.console;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/console/videoAdd")
public class VideoAddController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String videotitle = req.getParameter("videotitle");
        String videodesc = req.getParameter("videodesc");
        String videovlog = req.getParameter("videovlog");
        String videourl = req.getParameter("videourl");


        System.out.println(videotitle + " " + videodesc + " " + videovlog);


    }
}
