package com.app.dao.impl;

import com.app.dao.LoginDao;
import com.app.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class LoginDaoImpl implements LoginDao {


    @Override
    public Boolean loginUser(String userName,String password) throws SQLException {
        Connection conn = null;         // 数据库连接
        PreparedStatement ps = null;    // 执行SQL语句接口
        ResultSet rs = null;            // 查询返回的结果
        String sql = null;              // SQL语句 - select

        conn = DruidUtil.getInstance().getConnection();
        sql = "select * from t_user";
        ps = conn.prepareStatement(sql);
        rs = ps.executeQuery();         // 执行查询操作

        while (rs.next()) {              // 取出数据
             String username = rs.getString("username");
             String  passWord = rs.getString("password");
             if (username.equals(userName) && passWord.equals(password)) {
                DruidUtil.getInstance().closeConnection(conn);
                return true;
             }
        }

        DruidUtil.getInstance().closeConnection(conn);
        return false;
    }
}
