package com.app.controller.console;

import com.app.service.FqService;
import com.app.service.HomeVideoService;
import com.app.service.VideoService;
import com.app.service.impl.FqServiceImpl;
import com.app.service.impl.HomeVideoServiceImpl;
import com.app.service.impl.VideoServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@WebServlet("/console/fq")
public class FqController  extends HttpServlet{

    // 依赖业务层接口 - VideoService
    private FqService fqService = new FqServiceImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取数据

        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/plain;charset=utf-8");
        String fnum = req.getParameter("fnum");
        String lnum = req.getParameter("lnum");
        List list = null;
        try {
            list = fqService.getFqVideo(fnum,lnum);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // 设置响应类型
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/plain;charset=utf-8");

        // 解析成json数据 {'code':200, 'msg': 'success', newslist:[]}
        ObjectMapper objectMapper = new ObjectMapper();
        Map map = new HashMap();
        map.put("code", 200);
        map.put("msg", "success");
        map.put("newslist", list);
        String json = objectMapper.writeValueAsString(map);

        // 输出数据
        PrintWriter out = resp.getWriter();
        out.println(json);
        out.close();
    }
}

