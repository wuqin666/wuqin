package com.app.controller.console;

import com.app.service.HelloService;
import com.app.service.LoginService;
import com.app.service.impl.HelloServiceImpl;
import com.app.service.impl.LoginServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/console/login")
public class LoginController extends HttpServlet {

    private LoginService loginService = new LoginServiceImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/plain;charset=utf-8");
        String userName = req.getParameter("username");
        String password = req.getParameter("password");
        LoginService loginService = new LoginServiceImpl();
        boolean loginUser = false;

        try {
            loginUser = loginService.loginUser(userName,password);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String s = String .valueOf(loginUser);
        System.out.println(s);


        ObjectMapper objectMapper = new ObjectMapper(); // 解析Java对象, 生成json
        Map<String,Object> map = new HashMap<>();       // 存储数据
        map.put("code", 200);
        map.put("msg", "success");
        map.put("newslist",s);
        String json = objectMapper.writeValueAsString(map);

        PrintWriter out = resp.getWriter();
        out.println(json);
        out.close();
    }
    }
