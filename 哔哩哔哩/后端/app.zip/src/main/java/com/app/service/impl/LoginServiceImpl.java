package com.app.service.impl;

import com.app.dao.LoginDao;
import com.app.dao.impl.LoginDaoImpl;
import com.app.service.LoginService;
import sun.nio.cs.US_ASCII;

import java.sql.SQLException;
import java.util.List;

public class LoginServiceImpl implements LoginService {

    private LoginDao loginDao = new LoginDaoImpl();


    @Override
    public boolean loginUser(String userName, String password) throws SQLException {
        return loginDao.loginUser(userName,password);
    }
}
