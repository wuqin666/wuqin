package com.app.dao.impl;

import com.app.dao.FqDao;
import com.app.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FqDaoImpl implements FqDao {



    @Override
    public List getFqVideo(String fnum,String lnum) throws SQLException {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            String sql = null;
            List list = new ArrayList();

            conn = DruidUtil.getInstance().getConnection();
            sql = "select * from t_video limit ?,?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1,Integer.parseInt(fnum));
            ps.setInt(2,Integer.parseInt(lnum));
            rs = ps.executeQuery();
            while(rs.next()) {
                String videoid = rs.getString("videoid");
                String videotitle = rs.getString("videotitle");
                String videodate = rs.getString("videodate");
                String videotime = rs.getString("videotime");
                String videocoverimg = rs.getString("videocoverimg");
                String videourl = rs.getString("videourl");
                String videoauthor = rs.getString("videoauthor");
                String videocommentnum = rs.getString("videocommentnum");
                int videoplaynum = rs.getInt("videoplaynum");
                int videogoodnum = rs.getInt("videogoodnum");
                Map<String, Object> map = new HashMap<>();
                map.put("videoid", videoid);
                map.put("videotitle", videotitle);
                map.put("videodate", videodate);
                map.put("videotime", videotime);
                map.put("videocoverimg", videocoverimg);
                map.put("videourl", videourl);
                map.put("videoauthor", videoauthor);
                map.put("videocommentnum", videocommentnum);
                map.put("videoplaynum", videoplaynum);
                map.put("videogoodnum", videogoodnum);
                list.add(map);
            }
            DruidUtil.getInstance().closeConnection(conn);
            return list;
        }
}

