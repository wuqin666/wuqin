package com.app.service.impl;

import com.app.dao.LoginUserDao;
import com.app.dao.VideoDao;
import com.app.dao.impl.LoginUserDaoImpl;
import com.app.dao.impl.VideoDaoImpl;
import com.app.service.LoginUserService;

import java.sql.SQLException;
import java.util.List;

public class LoginUserServiceImpl  implements LoginUserService {

    private LoginUserDao loginUserDao = new LoginUserDaoImpl();

    @Override
    public List getLoginUser() throws SQLException {
        return loginUserDao.getLoginUser();
    }
}
