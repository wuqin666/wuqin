package com.app.service.impl;

import com.app.dao.CommentUserDao;
import com.app.dao.impl.CommentUserDaoImpl;
import com.app.service.CommentUserService;
import sun.plugin.com.event.COMEventListener;

import java.sql.SQLException;
import java.util.List;

public class CommentUsersServiceImpl implements CommentUserService {
    private CommentUserDao commentUserDao = new CommentUserDaoImpl();

    @Override
    public List getUserinfoByList() throws SQLException {
        return commentUserDao.getUserinfoByList();
    }
}
