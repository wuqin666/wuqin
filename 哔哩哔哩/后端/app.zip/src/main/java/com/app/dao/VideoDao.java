package com.app.dao;

import java.sql.SQLException;
import java.util.List;

public interface VideoDao {

    public List getVideo() throws SQLException;

    List getVideoByTitle(String videoTitle) throws SQLException;
}
