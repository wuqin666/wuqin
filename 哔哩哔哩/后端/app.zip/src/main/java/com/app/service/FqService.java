package com.app.service;

import java.sql.SQLException;
import java.util.List;

public interface FqService {

    public List getFqVideo(String fnum,String lnum) throws SQLException;
}
