package com.app.dao;

import java.sql.SQLException;
import java.util.List;

public interface LoginUserDao {
    public List getLoginUser() throws SQLException;
}
