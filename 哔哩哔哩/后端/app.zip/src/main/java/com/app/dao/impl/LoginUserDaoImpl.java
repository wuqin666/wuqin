package com.app.dao.impl;

import com.app.dao.LoginUserDao;
import com.app.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoginUserDaoImpl implements LoginUserDao {
    @Override
    public List getLoginUser() throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = null;
        List list = new ArrayList();

        conn = DruidUtil.getInstance().getConnection();
        sql = "select * from t_user";
        ps = conn.prepareStatement(sql);
        rs = ps.executeQuery();
        while(rs.next()) {
            String username = rs.getString("username");
            String password = rs.getString("password");
            Map<String, Object> map = new HashMap<>();
            map.put("username", username);
            map.put("password", password);
            list.add(map);
        }
        DruidUtil.getInstance().closeConnection(conn);
        return list;
    }
}
