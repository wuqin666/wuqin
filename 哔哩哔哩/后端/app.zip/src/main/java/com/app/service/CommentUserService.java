package com.app.service;

import java.sql.SQLException;
import java.util.List;

public interface CommentUserService {
    public List getUserinfoByList() throws SQLException;
}
