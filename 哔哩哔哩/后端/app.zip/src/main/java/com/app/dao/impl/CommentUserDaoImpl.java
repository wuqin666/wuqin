package com.app.dao.impl;

import com.app.dao.CommentUserDao;
import com.app.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommentUserDaoImpl implements CommentUserDao {
    @Override
    public List getUserinfoByList() throws SQLException {
        Connection conn = null;         // 数据库连接
        PreparedStatement ps = null;    // 执行SQL语句接口
        ResultSet rs = null;            // 查询返回的结果
        String sql = null;              // SQL语句 - select
        List list = new ArrayList();    //集合存储数据

        conn = DruidUtil.getInstance().getConnection();//使用工具类进行连接
        sql = "select * from comment_user";
        ps = conn.prepareStatement(sql); //sql语句放入内存
        rs = ps.executeQuery();         // 执行查询操作

        while(rs.next()) {              // 取出数据
            String t_userid = rs.getString("t_userid");
            String t_username = rs.getString("t_username");
            String t_userimg = rs.getString("t_userimg");
            String t_usercomment = rs.getString("t_usercomment");
            String t_usertitle = rs.getString("t_usertitle");
            String t_userlikenum = rs.getString("t_userlikenum");
            String t_usertrannum = rs.getString("t_usertrannum");
            String videosrc = rs.getString("videosrc");
            String videofans = rs.getString("videofans");
            String videoupdate = rs.getString("videoupdate");
            String videonum = rs.getString("videonum");
            Map<String,Object> map = new HashMap<>();
            map.put("t_userid",t_userid);
            map.put("t_username",t_username);
            map.put("t_userimg",t_userimg);
            map.put("t_usercomment",t_usercomment);
            map.put("t_usertitle",t_usertitle);
            map.put("t_userlikenum",t_userlikenum);
            map.put("t_usertrannum",t_usertrannum);
            map.put("videosrc",videosrc);
            map.put("videofans",videofans);
            map.put("videoupdate",videoupdate);
            map.put("videonum",videonum);

            list.add(map);             //满足存储的数据格式
        }

        DruidUtil.getInstance().closeConnection(conn);//关闭连接
        return list;
    }
}
