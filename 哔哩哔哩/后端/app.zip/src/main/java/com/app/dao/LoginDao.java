package com.app.dao;



import java.sql.SQLException;


public interface LoginDao  {

      Boolean loginUser(String userName,String password)throws SQLException;
}
