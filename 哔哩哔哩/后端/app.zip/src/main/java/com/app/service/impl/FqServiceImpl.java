package com.app.service.impl;

import com.app.dao.FqDao;
import com.app.dao.impl.FqDaoImpl;
import com.app.service.FqService;

import java.sql.SQLException;
import java.util.List;

public class FqServiceImpl implements FqService {

    private FqDao fqDao = new FqDaoImpl();

    @Override
    public List getFqVideo(String fnum,String lnum) throws SQLException {
        return fqDao.getFqVideo(fnum,lnum);
    }

}
