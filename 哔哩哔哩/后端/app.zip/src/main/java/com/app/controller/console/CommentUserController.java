package com.app.controller.console;

import com.app.service.CommentUserService;
import com.app.service.impl.CommentUsersServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/console/commentuser")
public class CommentUserController extends HttpServlet {
    private CommentUserService commentUserService = new CommentUsersServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List list = null;
        try {
            list = commentUserService.getUserinfoByList();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //设置中文编码
        //设置响应类型
        //生成json数据
        //输出json数据
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/plain;charset=utf-8");
        ObjectMapper objectMapper = new ObjectMapper(); // 解析Java对象, 生成json

        Map<String,Object> map = new HashMap<>();       // 存储数据
        map.put("code", 200);
        map.put("msg", "success");
        map.put("newlist",list);
        String s = objectMapper.writeValueAsString(map);

        PrintWriter out = resp.getWriter();
        out.println(s);
        out.close();
    }
}
