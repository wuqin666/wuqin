package com.app.controller.console;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

@WebServlet("/console/videoUpload")
public class VideoUploadController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String savePath = "D:/upload"; // 保存路径
        File file = new File(savePath); // File 文件操作
        if(!file.exists()) {
            file.mkdirs();
        }

        DiskFileItemFactory diskFileItemFactory = new DiskFileItemFactory(); // 上传文件工厂类
        ServletFileUpload servletFileUpload = new ServletFileUpload(diskFileItemFactory); // 上传文件核心类
        servletFileUpload.setHeaderEncoding("utf-8");

        // 判断是否是上传文件请求 - 安全验证
        // <form enctype='multipart/form-data'>
        if(!ServletFileUpload.isMultipartContent(req)) {
            return;
        }

        // 上传文件
        try {
            List<FileItem> list = servletFileUpload.parseRequest(req); // 解析文件-上传文件保存list里面
            for (FileItem item : list) {
                if(item.isFormField()) {
                    // 普通文本内容
                } else {
                    // 视频;图片;音频-文件
                    String name = item.getName();
                    System.out.println("name == " + name);

                    // 保存文件
                    InputStream is = item.getInputStream(); // 文件二进制流
                    OutputStream os = new FileOutputStream(savePath + "/" + name);

                    int i = -1; // 上传结束标记
                    byte[] b = new byte[1024]; // 缓存
                    while((i = is.read(b)) != -1) {
                        os.write(b, 0, i);
                    }
                    is.close();
                    os.close();
                    item.delete(); // 删除临时文件
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
