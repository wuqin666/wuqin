package com.app.dao.impl;

import com.app.dao.HomeVideoDao;
import com.app.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeVideoImpl implements HomeVideoDao {
    @Override
    public List getHomeVideo() throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = null;
        List list = new ArrayList();

        conn = DruidUtil.getInstance().getConnection();
        sql = "select * from t_video";
        ps = conn.prepareStatement(sql);
        rs = ps.executeQuery();
        while(rs.next()) {
            String videoid = rs.getString("videoid");
            String videotitle = rs.getString("videotitle");
            String videodate = rs.getString("videodate");
            String videotime = rs.getString("videotime");
            String videoauthor = rs.getString("videoauthor");
            String videocoverimg = rs.getString("videocoverimg");
            String videourl = rs.getString("videourl");
            String videtype = rs.getString("videotype");
            String videoimg = rs.getString("videoimg");
            int videoplaynum = rs.getInt("videoplaynum");
            int videogoodnum = rs.getInt("videogoodnum");
            int videocommentnum = rs.getInt("videocommentnum");
            int videofans = rs.getInt("videofans");
            Map<String, Object> map = new HashMap<>();
            map.put("videoid", videoid);
            map.put("videotitle", videotitle);
            map.put("videodate", videodate);
            map.put("videotime", videotime);
            map.put("videocoverimg", videocoverimg);
            map.put("videourl", videourl);
            map.put("videotype",videtype);
            map.put("videoauthor", videoauthor);
            map.put("videoplaynum", videoplaynum);
            map.put("videogoodnum", videogoodnum);
            map.put("videoimg",videoimg);
            map.put("videocommentnum", videocommentnum);
            map.put("videofans", videofans);
            list.add(map);
        }
        DruidUtil.getInstance().closeConnection(conn);
        return list;
    }

//    @Override
//    public List getVideoByTitle(String videoTitle) throws SQLException {
//        Connection conn = null;
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//        String sql = null;
//        List list = new ArrayList();
//
//        conn = DruidUtil.getInstance().getConnection();
//        sql = "select * from video where videotitle like concat('%',?, '%')";
//        ps = conn.prepareStatement(sql);
//        ps.setString(1, videoTitle);
//        rs = ps.executeQuery();
//        while(rs.next()) {
//            String videoid = rs.getString("videoid");
//            String videotitle = rs.getString("videotitle");
//            String videodate = rs.getString("videodate");
//            String videopicurl = rs.getString("videopicurl");
//            String videourl = rs.getString("videourl");
//            int videoplaynum = rs.getInt("videoplaynum");
//            int videogood = rs.getInt("videogood");
//            Map<String, Object> map = new HashMap<>();
//            map.put("videoid", videoid);
//            map.put("videotitle", videotitle);
//            map.put("videodate", videodate);
//            map.put("videopicurl", videopicurl);
//            map.put("videourl", videourl);
//            map.put("videoplaynum", videoplaynum);
//            map.put("videogood", videogood);
//            list.add(map);
//        }
//        DruidUtil.getInstance().closeConnection(conn);
//        return list;
//    }
}
