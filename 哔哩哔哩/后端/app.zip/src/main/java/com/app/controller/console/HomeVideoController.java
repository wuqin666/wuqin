package com.app.controller.console;

import com.app.service.HomeVideoService;
import com.app.service.VideoService;
import com.app.service.impl.HomeVideoServiceImpl;
import com.app.service.impl.VideoServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@WebServlet("/console/homevideo")
public class HomeVideoController  extends HttpServlet{

        // 依赖业务层接口 - VideoService
        private HomeVideoService homeVideoService = new HomeVideoServiceImpl();

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            // 获取数据
            List list = null;
            try {
                list = homeVideoService.getHomeVideo();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            // 设置响应类型
            resp.setCharacterEncoding("utf-8");
            resp.setContentType("text/plain;charset=utf-8");

            // 解析成json数据 {'code':200, 'msg': 'success', newslist:[]}
            ObjectMapper objectMapper = new ObjectMapper();
            Map map = new HashMap();
            map.put("code", 200);
            map.put("msg", "success");
            map.put("newslist", list);
            String json = objectMapper.writeValueAsString(map);

            // 输出数据
            PrintWriter out = resp.getWriter();
            out.println(json);
            out.close();
        }

//        @Override
//        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//            // 获取前端提交数据 - 参数: videotitle
//            String videoTitle = req.getParameter("videotitle");
//            System.out.println("videotitle = " + videoTitle);
//
//            // 找业务层接口 - VideoService
//            List list = null;
//            try {
//                list = videoService.getVideoByTitle(videoTitle);
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//
//            // 设置响应类型
//            resp.setCharacterEncoding("utf-8");
//            resp.setContentType("text/plain;charset=utf-8");
//
//            // 解析成json数据 {'code':200, 'msg': 'success', newslist:[]}
//            ObjectMapper objectMapper = new ObjectMapper();
//            Map map = new HashMap();
//            map.put("code", 200);
//            map.put("msg", "success");
//            map.put("newslist", list);
//            String json = objectMapper.writeValueAsString(map);
//
//            // 输出数据
//            PrintWriter out = resp.getWriter();
//            out.println(json);
//            out.close();
//        }
    }

